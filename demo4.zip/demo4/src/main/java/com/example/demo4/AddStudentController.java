package com.example.demo4;

import javafx.application.Preloader;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class AddStudentController implements Initializable {
    DatabaseConnection connectNow = new DatabaseConnection();
    Connection connectDB = connectNow.getConnection();
    @FXML
    public TextField NameTextField;
    @FXML
    public TextField MSVTextField;
    @FXML
    public TextField BirthdayTextField;
    @FXML
    public TextField CTDTTextField;
    @FXML
    public Button addStudentButton;




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
    }


    @FXML
    private void AddNewSTUDENT(ActionEvent event) {

        String name = NameTextField.getText();
        Integer ID = Integer.valueOf(MSVTextField.getText());
        String Birthday = BirthdayTextField.getText();
        String CTDT = CTDTTextField.getText();

        if (name.isEmpty() || Birthday.isEmpty() || CTDT.isEmpty() || ID.toString().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Thiếu thông tin");
            alert.showAndWait();
        } else {

            String insertQuery = "INSERT INTO SinhVien value (" + ID + "," +  "'" + name + "'" + "," +  "'" + Birthday + "'" + "," + "'" + CTDT + "'" + ");";
            try {
                if (checkDublicateMSV(ID)) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setContentText("Trùng thông tin MSV");
                    alert.showAndWait();
                } else {
                    Statement statement = connectDB.createStatement();
                    statement.executeUpdate(insertQuery);


                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setHeaderText(null);
                    alert.setContentText("Thêm thông tin sinh viên thành công");
                    alert.showAndWait();
                }

            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }

    @FXML
    public void EditStudent(ActionEvent event) {
//        String name = NameTextField.getText();
//        Integer ID = Integer.parseInt(MSVTextField.getText());
//        String Birthday = BirthdayTextField.getText();
//        String CTDT = CTDTTextField.getText();

        Controller controller = new Controller();
//        int getMSV = controller.StudentSearchTableView.getSelectionModel().getSelectedItem().getMSV();
//        System.out.println(controller.MSV);
//
//        NameTextField.setText("âff");


    }

    private boolean checkDublicateMSV(int MSV) {
        try {
            String queryCheck = "select MaSinhVien from SinhVien;";
            Statement statement = connectDB.createStatement();
            ResultSet queryOutput = statement.executeQuery(queryCheck);

            while(queryOutput.next()) {
                Integer QueryMSV = queryOutput.getInt("MaSinhVien");
                if (MSV == QueryMSV) {
                    return true;
                }
            }

        } catch (Exception e) {

        }
        return false;
    }

    public void SetTextField(Integer MSV, String Name, String Birthday, String Subject) {
        NameTextField.setText(Name);
        MSVTextField.setText(MSV.toString());
        BirthdayTextField.setText(Birthday);
        CTDTTextField.setText(Subject);
    }
}
