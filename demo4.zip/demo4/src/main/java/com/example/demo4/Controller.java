package com.example.demo4;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Callback;
import org.w3c.dom.events.MouseEvent;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Controller implements Initializable {
    @FXML
    public TextField NameTextField_edit;
    @FXML
    public TextField MSVTextField_edit;
    @FXML
    public TextField BirthdayTextField_edit;
    @FXML
    public TextField CTDTTextField_edit;


    private com.example.demo4.AddStudentController AddStudentController;
    DatabaseConnection connectNow = new DatabaseConnection();

    Connection connectDB = connectNow.getConnection();


    @FXML
    public TableView<StudentSearch> StudentSearchTableView;
    @FXML
    private TableColumn<StudentSearch, Integer> MSVTableColumn;
    @FXML
    private TableColumn<StudentSearch, String> StudentNameTableColumn;
    @FXML
    private TableColumn<StudentSearch, String> BirthdayTableColumn;
    @FXML
    private TableColumn<StudentSearch, String> StudentSubjectTableColumn;

    @FXML
    public TableView<StudentDetail> StudentDetailTableView;
    @FXML
    public TableColumn<StudentDetail, String> SubjectTableColumn;
    @FXML
    public TableColumn<StudentDetail, String> CreditTableColumn;
    @FXML
    public TableColumn<StudentDetail,Integer> IDTableColumn;
    @FXML
    public TableColumn<StudentDetail,String> NameTableColumn;


    @FXML
    private TextField StudentSBar;

    @FXML
    private TableColumn<Button, Button> EditButton;


    @FXML
    private void addNewStudent() {
        try {
            Parent parent = FXMLLoader.load(getClass().getResource("addNewStudent.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.initStyle(StageStyle.UTILITY);
            stage.show();
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    ObservableList<StudentSearch> StudentSearchObservableList = FXCollections.observableArrayList();
    ObservableList<StudentDetail> StudentDetailObservableList = FXCollections.observableArrayList();

    public void loadStudent() {
        String SearchStudent = "select MaSinhVien,Hovaten,NgaySinh,MaChuongTrinhDaoTao from sinhvien";
        try {
            Statement statement = connectDB.createStatement();
            ResultSet queryOutput = statement.executeQuery(SearchStudent);
            while(queryOutput.next()) {
                Integer QueryMSV = queryOutput.getInt("MaSinhVien");
                String QueryHovaten = queryOutput.getString("Hovaten");
                String QueryNgaySinh = queryOutput.getString("NgaySinh");
                String QuerySubject = queryOutput.getString("MaChuongTrinhDaoTao");
                StudentSearchObservableList.add(new StudentSearch(QueryMSV,QueryHovaten,QueryNgaySinh,QuerySubject));
            }
            MSVTableColumn.setCellValueFactory(new PropertyValueFactory<>("MSV"));
            StudentNameTableColumn.setCellValueFactory(new PropertyValueFactory<>("Name"));
            BirthdayTableColumn.setCellValueFactory(new PropertyValueFactory<>("Birthday"));
            StudentSubjectTableColumn.setCellValueFactory(new PropertyValueFactory<>("Subject"));
            StudentSearchTableView.setItems(StudentSearchObservableList);
            FilteredList<StudentSearch> filteredData = new FilteredList<>(StudentSearchObservableList, b -> true);
            StudentSBar.textProperty().addListener((observable,oldValue, newValue) -> {
                filteredData.setPredicate(StudentSearch -> {
                    if (newValue.isEmpty() || newValue.isBlank() || newValue == null) {
                        return true;
                    }
                    String searchKeyword = newValue.toLowerCase();
                    if (StudentSearch.getName().toLowerCase().indexOf(searchKeyword) > -1) {
                        return true;
                    } else if (StudentSearch.getMSV().toString().indexOf(searchKeyword) > -1) {
                        return true;
                    } else if (StudentSearch.getBirthday().indexOf(searchKeyword) > -1) {
                        return true;
                    } else if (StudentSearch.getSubject().indexOf(searchKeyword) > -1) {
                        return true;
                    } else return false;
                });
            });

            SortedList<StudentSearch> sortedData = new SortedList<>(filteredData);
            sortedData.comparatorProperty().bind(StudentSearchTableView.comparatorProperty());

            StudentSearchTableView.setItems(sortedData);



        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    @Override
    public void initialize (URL url, ResourceBundle resource) {
        loadStudent();
    }

    @FXML
    public void refresh(ActionEvent event) {
        StudentSearchObservableList.clear();
        loadStudent();
    }

    @FXML
    private void removeStudent(ActionEvent event) {
        try {
            Integer selectedItem = StudentSearchTableView.getSelectionModel().getSelectedItem().getMSV();
            String queryDelete = "DELETE FROM sinhvien WHERE MaSinhVien='" + selectedItem + "';";
            Statement statement = connectDB.createStatement();
            statement.execute(queryDelete);
            refresh(event);
        } catch (Exception e) {
            System.out.println(e);
        }
    }




    public int MSV;
    public int getMSV() {
        return MSV;
    }


    public int MSV_;
    @FXML
    public void editButton(ActionEvent event) {
        try {

            int MSV = StudentSearchTableView.getSelectionModel().getSelectedItem().getMSV();
            String Name = StudentSearchTableView.getSelectionModel().getSelectedItem().getName();
            String Birthday = StudentSearchTableView.getSelectionModel().getSelectedItem().getBirthday();
            String Subject = StudentSearchTableView.getSelectionModel().getSelectedItem().getSubject();



            FXMLLoader loader = new FXMLLoader ();
            loader.setLocation(getClass().getResource("editStudentController.fxml"));
            loader.load();
            EditStudentController editStudentController =loader.getController();
            Parent parent = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(parent));
            stage.initStyle(StageStyle.UTILITY);
            stage.show();
            editStudentController.SetTextField(MSV, Name, Birthday, Subject);
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public boolean click = false;
    @FXML
    public void detailButton(ActionEvent event) {


        try {
            loadStudentDetail();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @FXML
    public void refresh_(ActionEvent event) {

    }



    int temp_MSV;
    String temp_Name;
    public void loadStudentDetail() {

        Integer selectedID = StudentSearchTableView.getSelectionModel().getSelectedItem().getMSV();
        String selectedName = StudentSearchTableView.getSelectionModel().getSelectedItem().getName();
        String selectedBirthday = StudentSearchTableView.getSelectionModel().getSelectedItem().getBirthday();
        String selectedSubject = StudentSearchTableView.getSelectionModel().getSelectedItem().getSubject();





//        String studentDetail = "select distinct " + "sinhvien.MaSinhVien" + "," + "'" +"sinhvien.Hovaten" +"' ," + " monhoc.tenmonhoc, monhoc.sotinchi  from sinhvien inner join monhoc on monhoc.MaChuongTrinhDaoTao = sinhvien.MaChuongTrinhDaoTao;\n";
        String studentDetail = "select distinct sinhvien.MaSinhVien, sinhvien.Hovaten,monhoc.tenmonhoc, monhoc.sotinchi  from sinhvien inner join monhoc on monhoc.MaChuongTrinhDaoTao = sinhvien.MaChuongTrinhDaoTao;\n";
        System.out.println(studentDetail);
        try {
            Statement statement = connectDB.createStatement();
            ResultSet queryOutput = statement.executeQuery(studentDetail);

            while(queryOutput.next()) {
                Integer QueryMSV = queryOutput.getInt("MaSinhVien");
                String QueryHovaten = queryOutput.getString("Hovaten");
                String QuerySubject = queryOutput.getString("tenmonhoc");
                Integer QueryCredit = queryOutput.getInt("sotinchi");
                if (QueryMSV.equals(selectedID) && QueryHovaten.equals(selectedName) ) {
                    StudentDetailObservableList.add(new StudentDetail(QueryMSV,QueryHovaten,QuerySubject,QueryCredit));
                }

            }
            IDTableColumn.setCellValueFactory(new PropertyValueFactory<>("MSV"));
            NameTableColumn.setCellValueFactory(new PropertyValueFactory<>("Name"));
            SubjectTableColumn.setCellValueFactory(new PropertyValueFactory<>("mon"));
            CreditTableColumn.setCellValueFactory(new PropertyValueFactory<>("Credit"));

            StudentDetailTableView.setItems(StudentDetailObservableList);



        }
        catch (Exception e) {

        }

    }

}