package com.example.demo4;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class DetailController implements Initializable {
    @FXML
    public TableView<StudentDetail> StudentDetailTableView;
    @FXML
    public TableColumn<StudentDetail, String> SubjectTableColumn;
    @FXML
    public TableColumn<StudentDetail, String> CreditTableColumn;

    @FXML
    public TableColumn<StudentDetail,Integer> IDTableColumn;
    @FXML
    public TableColumn<StudentDetail,String> NameTableColumn;

    boolean click = false;
    DatabaseConnection connectNow = new DatabaseConnection();

    Connection connectDB = connectNow.getConnection();



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void load() throws SQLException {
        Statement statement = connectDB.createStatement();


    }
}
