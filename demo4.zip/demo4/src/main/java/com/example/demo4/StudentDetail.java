package com.example.demo4;

public class StudentDetail {
    private int MSV;
    private String Name;
    private String mon;
    private int Credit;

    StudentDetail (int MSV, String Name, String mon, int Credit) {
        this.MSV = MSV;
        this.Name = Name;
        this.mon = mon;
        this.Credit = Credit;
    }

    public int getMSV() {
        return MSV;
    }

    public String getName() {
        return Name;
    }

    public String getMon() {
        return mon;
    }

    public int getCredit() {
        return Credit;
    }

    public void setMSV(int MSV) {
        this.MSV = MSV;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setMon(String mon) {
        this.mon = mon;
    }

    public void setCredit(int credit) {
        Credit = credit;
    }
}
