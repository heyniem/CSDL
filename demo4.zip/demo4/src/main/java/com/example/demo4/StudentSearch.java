package com.example.demo4;

public class StudentSearch {
    int MSV;
    String Name;

    String Birthday;
    String Subject;

    public StudentSearch(Integer MSV, String Name, String Birthday, String Subject) {
        this.MSV = MSV;
        this.Name = Name;
        this.Birthday = Birthday;
        this.Subject = Subject;
    }

    public Integer getMSV() {
        return MSV;
    }

    public String getName() {
        return Name;
    }

    public void setMSV(Integer MSV) {
        this.MSV = MSV;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getBirthday() {
        return Birthday;
    }

    public String getSubject() {
        return Subject;
    }

    public void setBirthday(String birthday) {
        Birthday = birthday;
    }

    public void setSubject(String subject) {
        Subject = subject;
    }
}
