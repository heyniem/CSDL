package com.example.demo4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class EditStudentController implements Initializable {
    DatabaseConnection connectNow = new DatabaseConnection();
    Connection connectDB = connectNow.getConnection();

    @FXML
    public TextField NameTextField_edit;
    @FXML
    public TextField MSVTextField_edit;
    @FXML
    public TextField BirthdayTextField_edit;
    @FXML
    public TextField CTDTTextField_edit;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }


    @FXML
    public void Edit(ActionEvent event) {

        Integer MSV = Integer.valueOf(MSVTextField_edit.getText());
        String Name = NameTextField_edit.getText();
        String Birthday = BirthdayTextField_edit.getText();
        String Subject = CTDTTextField_edit.getText();

        String editQuery = "UPDATE sinhvien SET MaSinhVien = " + MSV + ",Hovaten = '" +Name + "',NgaySinh = '" + Birthday + " ', MaChuongTrinhDaoTao ='" +Subject + "' WHERE MaSinhVien = '" + MSV + "';";

        try {

            Statement statement = connectDB.createStatement();
            statement.executeUpdate(editQuery);
            System.out.println(editQuery);

        } catch (Exception e) {

        }


    }
    public void SetTextField(Integer MSV, String Name, String Birthday, String Subject) {
        NameTextField_edit.setText(Name);
        MSVTextField_edit.setText(MSV.toString());
        BirthdayTextField_edit.setText(Birthday);
        CTDTTextField_edit.setText(Subject);
    }


}
